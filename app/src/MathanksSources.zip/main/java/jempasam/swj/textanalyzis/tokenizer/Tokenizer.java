package jempasam.swj.textanalyzis.tokenizer;

import java.util.Iterator;

public interface Tokenizer extends Iterator<String>{
}
