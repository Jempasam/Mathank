package jempasam.swj.objectmanager;

public interface Prototype extends Cloneable{
	Object clone();
}
